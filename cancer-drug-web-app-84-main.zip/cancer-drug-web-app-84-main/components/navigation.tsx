"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

export function Navigation() {
  const pathname = usePathname()

  return (
    <nav className="border-b bg-card">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-8">
            <Link href="/" className="text-xl font-semibold text-foreground">
              CancerDrug AI
            </Link>
            <div className="hidden md:flex space-x-6">
              <Link
                href="/"
                className={cn(
                  "text-sm font-medium transition-colors hover:text-primary",
                  pathname === "/" ? "text-primary" : "text-muted-foreground",
                )}
              >
                Home
              </Link>
              <Link
                href="/login"
                className={cn(
                  "text-sm font-medium transition-colors hover:text-primary",
                  pathname === "/login" ? "text-primary" : "text-muted-foreground",
                )}
              >
                Doctor Login
              </Link>
              <Link
                href="/about"
                className={cn(
                  "text-sm font-medium transition-colors hover:text-primary",
                  pathname === "/about" ? "text-primary" : "text-muted-foreground",
                )}
              >
                About
              </Link>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <Button asChild>
              <Link href="/login">Doctor Login</Link>
            </Button>
          </div>
        </div>
      </div>
    </nav>
  )
}
