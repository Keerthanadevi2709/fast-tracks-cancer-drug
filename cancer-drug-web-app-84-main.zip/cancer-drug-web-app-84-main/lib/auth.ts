export interface DoctorSession {
  email: string
  name: string
  loginTime: string
}

export function getDoctorSession(): DoctorSession | null {
  if (typeof window === "undefined") return null

  try {
    const session = localStorage.getItem("doctorSession")
    return session ? JSON.parse(session) : null
  } catch {
    return null
  }
}

export function clearDoctorSession(): void {
  if (typeof window !== "undefined") {
    localStorage.removeItem("doctorSession")
  }
}

export function isAuthenticated(): boolean {
  return getDoctorSession() !== null
}
