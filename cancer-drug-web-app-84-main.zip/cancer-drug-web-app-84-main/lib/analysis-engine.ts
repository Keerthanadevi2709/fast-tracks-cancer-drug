export interface PatientAnalysis {
  patientId: string
  name: string
  age: string
  gender: string
  cancerType: string
  geneName: string
  geneExpressionLevel: string
  mutationStatus: string
  previousTreatments: string
  analysisId: string
  timestamp: string
}

export interface TreatmentRecommendation {
  drugName: string
  mechanism: string
  dosage: string
  administration: string
  reasoning: string
}

export interface AnalysisResults {
  recommendation: TreatmentRecommendation
  successProbability: number
  riskFactors: string[]
  patientFeedback: string
  postTreatmentPlan: string
  doctorGuidance: string
  drugEffectiveness: { drug: string; score: number }[]
  confidenceLevel: "High" | "Medium" | "Low"
}

export function generateAnalysisResults(patientData: PatientAnalysis): AnalysisResults {
  // Simulate AI analysis based on patient data
  const { cancerType, geneName, mutationStatus, geneExpressionLevel } = patientData

  // Drug recommendations based on cancer type and genetic profile
  const drugDatabase: Record<string, Record<string, TreatmentRecommendation>> = {
    aml: {
      flt3_mutated: {
        drugName: "Midostaurin",
        mechanism: "FLT3 kinase inhibitor",
        dosage: "50mg twice daily",
        administration: "Oral, with food",
        reasoning:
          "FLT3 mutations are present in ~30% of AML patients. Midostaurin specifically targets FLT3-ITD and FLT3-TKD mutations.",
      },
      npm1_mutated: {
        drugName: "Venetoclax + Azacitidine",
        mechanism: "BCL-2 inhibitor + DNA methyltransferase inhibitor",
        dosage: "Venetoclax 400mg daily + Azacitidine 75mg/m²",
        administration: "Oral + Subcutaneous injection",
        reasoning:
          "NPM1 mutations often co-occur with favorable prognosis markers. Combination therapy shows enhanced efficacy.",
      },
    },
    breast: {
      brca1_mutated: {
        drugName: "Olaparib",
        mechanism: "PARP inhibitor",
        dosage: "300mg twice daily",
        administration: "Oral",
        reasoning:
          "BRCA1 mutations create homologous recombination deficiency, making cells vulnerable to PARP inhibition.",
      },
      her2_high: {
        drugName: "Trastuzumab + Pertuzumab",
        mechanism: "HER2 receptor antagonists",
        dosage: "Loading dose followed by maintenance",
        administration: "Intravenous infusion",
        reasoning: "HER2 overexpression drives tumor growth. Dual HER2 blockade improves outcomes significantly.",
      },
    },
    lung: {
      egfr_mutated: {
        drugName: "Osimertinib",
        mechanism: "Third-generation EGFR tyrosine kinase inhibitor",
        dosage: "80mg once daily",
        administration: "Oral",
        reasoning:
          "EGFR mutations are found in ~15% of lung adenocarcinomas. Osimertinib shows superior efficacy and CNS penetration.",
      },
    },
  }

  // Generate recommendation
  const key = `${geneName.toLowerCase()}_${mutationStatus === "mutated" ? "mutated" : geneExpressionLevel.toLowerCase()}`
  const recommendation = drugDatabase[cancerType]?.[key] || {
    drugName: "Standard Chemotherapy Protocol",
    mechanism: "Multi-agent cytotoxic therapy",
    dosage: "Per institutional guidelines",
    administration: "Intravenous",
    reasoning: "Based on current patient profile, standard chemotherapy remains the recommended first-line treatment.",
  }

  // Calculate success probability based on various factors
  let baseSuccess = 65

  // Adjust based on mutation status
  if (mutationStatus === "mutated" && ["flt3", "brca1", "brca2", "egfr"].includes(geneName.toLowerCase())) {
    baseSuccess += 15 // Targeted therapy available
  }

  // Adjust based on expression level
  if (geneExpressionLevel === "high") baseSuccess += 8
  else if (geneExpressionLevel === "low") baseSuccess -= 5

  // Adjust based on age
  const age = Number.parseInt(patientData.age)
  if (age < 50) baseSuccess += 10
  else if (age > 70) baseSuccess -= 8

  // Adjust based on previous treatments
  if (patientData.previousTreatments.toLowerCase().includes("chemotherapy")) {
    baseSuccess -= 12 // Previous treatment resistance
  }

  const successProbability = Math.min(95, Math.max(25, baseSuccess))

  // Generate drug effectiveness scores
  const drugEffectiveness = [
    { drug: recommendation.drugName, score: successProbability },
    { drug: "Alternative Option 1", score: Math.max(20, successProbability - 15) },
    { drug: "Alternative Option 2", score: Math.max(15, successProbability - 25) },
    { drug: "Standard Protocol", score: Math.max(30, successProbability - 20) },
  ]

  // Generate risk factors
  const riskFactors = []
  if (age > 65) riskFactors.push("Advanced age may affect treatment tolerance")
  if (patientData.previousTreatments) riskFactors.push("Previous treatment history may indicate resistance patterns")
  if (geneExpressionLevel === "low") riskFactors.push("Low gene expression may reduce treatment efficacy")
  if (mutationStatus === "wild-type") riskFactors.push("Wild-type status may limit targeted therapy options")

  return {
    recommendation,
    successProbability,
    riskFactors,
    patientFeedback: `Based on analysis of similar patients with ${cancerType} and ${geneName} ${mutationStatus} status, ${recommendation.drugName} has shown favorable outcomes with manageable side effects. Patients typically report improved quality of life within 4-6 weeks of treatment initiation.`,
    postTreatmentPlan: `Continue ${recommendation.drugName} for initial 3-month cycle with bi-weekly monitoring. Follow-up imaging at 6 weeks to assess response. Consider maintenance therapy with supportive care including anti-nausea medications and regular blood work monitoring.`,
    doctorGuidance: `Clinical recommendation: Proceed with ${recommendation.drugName}-based therapy with ${successProbability}% predicted success rate. Monitor for ${geneName}-related biomarkers and adjust dosing based on patient tolerance. Consider genetic counseling if hereditary factors are suspected.`,
    drugEffectiveness,
    confidenceLevel: successProbability > 80 ? "High" : successProbability > 60 ? "Medium" : "Low",
  }
}
