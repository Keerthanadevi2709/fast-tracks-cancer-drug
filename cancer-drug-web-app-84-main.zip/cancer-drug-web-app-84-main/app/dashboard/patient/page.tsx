"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { AuthGuard } from "@/components/auth-guard"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2 } from "lucide-react"

interface PatientData {
  patientId: string
  name: string
  age: string
  gender: string
  cancerType: string
  geneName: string
  geneExpressionLevel: string
  mutationStatus: string
  previousTreatments: string
}

export default function PatientDataPage() {
  const [formData, setFormData] = useState<PatientData>({
    patientId: "",
    name: "",
    age: "",
    gender: "",
    cancerType: "",
    geneName: "",
    geneExpressionLevel: "",
    mutationStatus: "",
    previousTreatments: "",
  })
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [error, setError] = useState("")
  const router = useRouter()

  const handleInputChange = (field: keyof PatientData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsAnalyzing(true)
    setError("")

    // Validate required fields
    const requiredFields = [
      "patientId",
      "name",
      "age",
      "gender",
      "cancerType",
      "geneName",
      "geneExpressionLevel",
      "mutationStatus",
    ]
    const missingFields = requiredFields.filter((field) => !formData[field as keyof PatientData])

    if (missingFields.length > 0) {
      setError("Please fill in all required fields.")
      setIsAnalyzing(false)
      return
    }

    try {
      // Simulate analysis processing
      await new Promise((resolve) => setTimeout(resolve, 3000))

      // Store patient data for analysis results
      localStorage.setItem(
        "currentPatientAnalysis",
        JSON.stringify({
          ...formData,
          analysisId: Date.now().toString(),
          timestamp: new Date().toISOString(),
        }),
      )

      // Redirect to analysis results
      router.push("/dashboard/analysis")
    } catch (err) {
      setError("Analysis failed. Please try again.")
    } finally {
      setIsAnalyzing(false)
    }
  }

  return (
    <AuthGuard>
      <DashboardLayout currentPage="patient">
        <div className="p-6">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-foreground">Patient Data Entry</h1>
            <p className="text-muted-foreground mt-2">
              Enter comprehensive patient information for AI-powered treatment analysis.
            </p>
          </div>

          <Card className="max-w-4xl">
            <CardHeader>
              <CardTitle>Patient Information & Genomic Data</CardTitle>
              <CardDescription>
                Complete all fields to generate accurate treatment recommendations and success predictions.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleAnalyze} className="space-y-6">
                {/* Basic Patient Information */}
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="patientId">Patient ID *</Label>
                    <Input
                      id="patientId"
                      placeholder="e.g., P-2024-001"
                      value={formData.patientId}
                      onChange={(e) => handleInputChange("patientId", e.target.value)}
                      disabled={isAnalyzing}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="name">Patient Name *</Label>
                    <Input
                      id="name"
                      placeholder="Enter patient name"
                      value={formData.name}
                      onChange={(e) => handleInputChange("name", e.target.value)}
                      disabled={isAnalyzing}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="age">Age *</Label>
                    <Input
                      id="age"
                      type="number"
                      placeholder="Enter age"
                      value={formData.age}
                      onChange={(e) => handleInputChange("age", e.target.value)}
                      disabled={isAnalyzing}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="gender">Gender *</Label>
                    <Select
                      value={formData.gender}
                      onValueChange={(value) => handleInputChange("gender", value)}
                      disabled={isAnalyzing}
                      required
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select gender" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="male">Male</SelectItem>
                        <SelectItem value="female">Female</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Cancer Information */}
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="cancerType">Cancer Type *</Label>
                    <Select
                      value={formData.cancerType}
                      onValueChange={(value) => handleInputChange("cancerType", value)}
                      disabled={isAnalyzing}
                      required
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select cancer type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="aml">Acute Myeloid Leukemia (AML)</SelectItem>
                        <SelectItem value="breast">Breast Cancer</SelectItem>
                        <SelectItem value="lung">Lung Cancer</SelectItem>
                        <SelectItem value="colon">Colon Cancer</SelectItem>
                        <SelectItem value="prostate">Prostate Cancer</SelectItem>
                        <SelectItem value="ovarian">Ovarian Cancer</SelectItem>
                        <SelectItem value="pancreatic">Pancreatic Cancer</SelectItem>
                        <SelectItem value="melanoma">Melanoma</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="geneName">Gene Name *</Label>
                    <Select
                      value={formData.geneName}
                      onValueChange={(value) => handleInputChange("geneName", value)}
                      disabled={isAnalyzing}
                      required
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select gene" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="flt3">FLT3</SelectItem>
                        <SelectItem value="tp53">TP53</SelectItem>
                        <SelectItem value="npm1">NPM1</SelectItem>
                        <SelectItem value="idh1">IDH1</SelectItem>
                        <SelectItem value="idh2">IDH2</SelectItem>
                        <SelectItem value="brca1">BRCA1</SelectItem>
                        <SelectItem value="brca2">BRCA2</SelectItem>
                        <SelectItem value="egfr">EGFR</SelectItem>
                        <SelectItem value="kras">KRAS</SelectItem>
                        <SelectItem value="her2">HER2</SelectItem>
                        <SelectItem value="braf">BRAF</SelectItem>
                        <SelectItem value="pik3ca">PIK3CA</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="geneExpressionLevel">Gene Expression Level *</Label>
                    <Select
                      value={formData.geneExpressionLevel}
                      onValueChange={(value) => handleInputChange("geneExpressionLevel", value)}
                      disabled={isAnalyzing}
                      required
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select expression level" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="low">Low</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="mutationStatus">Mutation Status *</Label>
                    <Select
                      value={formData.mutationStatus}
                      onValueChange={(value) => handleInputChange("mutationStatus", value)}
                      disabled={isAnalyzing}
                      required
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select mutation status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="mutated">Mutated</SelectItem>
                        <SelectItem value="wild-type">Wild-type</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Previous Treatments */}
                <div className="space-y-2">
                  <Label htmlFor="previousTreatments">Previous Treatments</Label>
                  <Textarea
                    id="previousTreatments"
                    placeholder="Describe any previous treatments, medications, or therapies the patient has received..."
                    value={formData.previousTreatments}
                    onChange={(e) => handleInputChange("previousTreatments", e.target.value)}
                    disabled={isAnalyzing}
                    rows={4}
                  />
                </div>

                {error && (
                  <Alert variant="destructive">
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}

                <div className="flex justify-end space-x-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => router.push("/dashboard")}
                    disabled={isAnalyzing}
                  >
                    Cancel
                  </Button>
                  <Button type="submit" disabled={isAnalyzing} className="min-w-32">
                    {isAnalyzing ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Analyzing...
                      </>
                    ) : (
                      "Analyze Patient"
                    )}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </DashboardLayout>
    </AuthGuard>
  )
}
