"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { AuthGuard } from "@/components/auth-guard"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import type { AnalysisResults } from "@/lib/analysis-engine"
import { Search, Download, Eye, Calendar, Filter, FileText, TrendingUp } from "lucide-react"
import { format } from "date-fns"

interface PatientReport {
  patientId: string
  name: string
  age: string
  gender: string
  cancerType: string
  geneName: string
  geneExpressionLevel: string
  mutationStatus: string
  previousTreatments: string
  analysisId: string
  timestamp: string
  results: AnalysisResults
  reportId: string
}

export default function ReportsPage() {
  const [reports, setReports] = useState<PatientReport[]>([])
  const [filteredReports, setFilteredReports] = useState<PatientReport[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [filterType, setFilterType] = useState("all")
  const [selectedReport, setSelectedReport] = useState<PatientReport | null>(null)
  const router = useRouter()

  useEffect(() => {
    // Load reports from localStorage and add some dummy data if empty
    const savedReports = JSON.parse(localStorage.getItem("patientReports") || "[]")

    if (savedReports.length === 0) {
      // Add some dummy historical data for demonstration
      const dummyReports: PatientReport[] = [
        {
          patientId: "P-2024-001",
          name: "John Smith",
          age: "58",
          gender: "male",
          cancerType: "aml",
          geneName: "flt3",
          geneExpressionLevel: "high",
          mutationStatus: "mutated",
          previousTreatments: "None",
          analysisId: "A-001",
          timestamp: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
          reportId: "RPT-001",
          results: {
            recommendation: {
              drugName: "Midostaurin",
              mechanism: "FLT3 kinase inhibitor",
              dosage: "50mg twice daily",
              administration: "Oral, with food",
              reasoning: "FLT3 mutations are present in ~30% of AML patients.",
            },
            successProbability: 87,
            riskFactors: ["Advanced age may affect treatment tolerance"],
            patientFeedback: "Favorable outcomes expected based on similar patient profiles.",
            postTreatmentPlan: "Continue Midostaurin for initial 3-month cycle with bi-weekly monitoring.",
            doctorGuidance: "Proceed with Midostaurin-based therapy with high confidence.",
            drugEffectiveness: [
              { drug: "Midostaurin", score: 87 },
              { drug: "Alternative Option 1", score: 72 },
              { drug: "Alternative Option 2", score: 62 },
              { drug: "Standard Protocol", score: 67 },
            ],
            confidenceLevel: "High" as const,
          },
        },
        {
          patientId: "P-2024-002",
          name: "Sarah Johnson",
          age: "45",
          gender: "female",
          cancerType: "breast",
          geneName: "brca1",
          geneExpressionLevel: "medium",
          mutationStatus: "mutated",
          previousTreatments: "Previous chemotherapy",
          analysisId: "A-002",
          timestamp: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString(),
          reportId: "RPT-002",
          results: {
            recommendation: {
              drugName: "Olaparib",
              mechanism: "PARP inhibitor",
              dosage: "300mg twice daily",
              administration: "Oral",
              reasoning: "BRCA1 mutations create homologous recombination deficiency.",
            },
            successProbability: 78,
            riskFactors: ["Previous treatment history may indicate resistance patterns"],
            patientFeedback: "PARP inhibitors show good tolerance in BRCA-positive patients.",
            postTreatmentPlan: "Continue Olaparib with regular monitoring for side effects.",
            doctorGuidance: "Strong recommendation for PARP inhibitor therapy.",
            drugEffectiveness: [
              { drug: "Olaparib", score: 78 },
              { drug: "Alternative Option 1", score: 63 },
              { drug: "Alternative Option 2", score: 53 },
              { drug: "Standard Protocol", score: 58 },
            ],
            confidenceLevel: "High" as const,
          },
        },
      ]

      localStorage.setItem("patientReports", JSON.stringify(dummyReports))
      setReports(dummyReports)
      setFilteredReports(dummyReports)
    } else {
      setReports(savedReports)
      setFilteredReports(savedReports)
    }
  }, [])

  useEffect(() => {
    let filtered = reports

    // Filter by search term
    if (searchTerm) {
      filtered = filtered.filter(
        (report) =>
          report.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          report.patientId.toLowerCase().includes(searchTerm.toLowerCase()) ||
          report.results.recommendation.drugName.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    }

    // Filter by cancer type
    if (filterType !== "all") {
      filtered = filtered.filter((report) => report.cancerType === filterType)
    }

    setFilteredReports(filtered)
  }, [searchTerm, filterType, reports])

  const handleDownloadReport = (report: PatientReport) => {
    // In a real application, this would generate and download a PDF
    const reportData = {
      patientDetails: {
        id: report.patientId,
        name: report.name,
        age: report.age,
        gender: report.gender,
        cancerType: report.cancerType.toUpperCase(),
        geneticProfile: `${report.geneName} (${report.mutationStatus})`,
      },
      recommendation: report.results.recommendation,
      successProbability: report.results.successProbability,
      analysis: {
        patientFeedback: report.results.patientFeedback,
        postTreatmentPlan: report.results.postTreatmentPlan,
        doctorGuidance: report.results.doctorGuidance,
      },
      timestamp: report.timestamp,
    }

    // Create a downloadable text file for demo purposes
    const dataStr = JSON.stringify(reportData, null, 2)
    const dataUri = "data:application/json;charset=utf-8," + encodeURIComponent(dataStr)
    const exportFileDefaultName = `${report.patientId}_analysis_report.json`

    const linkElement = document.createElement("a")
    linkElement.setAttribute("href", dataUri)
    linkElement.setAttribute("download", exportFileDefaultName)
    linkElement.click()
  }

  const getConfidenceBadgeVariant = (confidence: string) => {
    switch (confidence) {
      case "High":
        return "default"
      case "Medium":
        return "secondary"
      case "Low":
        return "outline"
      default:
        return "outline"
    }
  }

  return (
    <AuthGuard>
      <DashboardLayout currentPage="reports">
        <div className="p-6 space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground">Analysis Reports</h1>
              <p className="text-muted-foreground mt-2">
                View and manage patient analysis reports and treatment recommendations.
              </p>
            </div>
            <Button onClick={() => router.push("/dashboard/patient")}>
              <FileText className="mr-2 h-4 w-4" />
              New Analysis
            </Button>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Reports</CardTitle>
                <FileText className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{reports.length}</div>
                <p className="text-xs text-muted-foreground">Generated analyses</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Average Success Rate</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {reports.length > 0
                    ? Math.round(reports.reduce((sum, r) => sum + r.results.successProbability, 0) / reports.length)
                    : 0}
                  %
                </div>
                <p className="text-xs text-muted-foreground">Predicted outcomes</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">High Confidence</CardTitle>
                <Badge variant="default" className="h-4 px-2 text-xs">
                  High
                </Badge>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {reports.filter((r) => r.results.confidenceLevel === "High").length}
                </div>
                <p className="text-xs text-muted-foreground">High confidence analyses</p>
              </CardContent>
            </Card>
          </div>

          {/* Filters */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Filter Reports</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search by patient name, ID, or drug..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
                <Select value={filterType} onValueChange={setFilterType}>
                  <SelectTrigger className="w-full sm:w-48">
                    <Filter className="mr-2 h-4 w-4" />
                    <SelectValue placeholder="Filter by cancer type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Cancer Types</SelectItem>
                    <SelectItem value="aml">AML</SelectItem>
                    <SelectItem value="breast">Breast Cancer</SelectItem>
                    <SelectItem value="lung">Lung Cancer</SelectItem>
                    <SelectItem value="colon">Colon Cancer</SelectItem>
                    <SelectItem value="prostate">Prostate Cancer</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Reports Table */}
          <Card>
            <CardHeader>
              <CardTitle>Patient Reports ({filteredReports.length})</CardTitle>
              <CardDescription>
                Click on any report to view detailed analysis or download the full report.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {filteredReports.length === 0 ? (
                <div className="text-center py-8">
                  <FileText className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                  <p className="text-muted-foreground">No reports found matching your criteria.</p>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Patient</TableHead>
                      <TableHead>Cancer Type</TableHead>
                      <TableHead>Recommended Drug</TableHead>
                      <TableHead>Success Rate</TableHead>
                      <TableHead>Confidence</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredReports.map((report) => (
                      <TableRow key={report.reportId}>
                        <TableCell>
                          <div>
                            <p className="font-medium">{report.name}</p>
                            <p className="text-sm text-muted-foreground">{report.patientId}</p>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">{report.cancerType.toUpperCase()}</Badge>
                        </TableCell>
                        <TableCell>{report.results.recommendation.drugName}</TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            <span className="font-medium">{report.results.successProbability}%</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant={getConfidenceBadgeVariant(report.results.confidenceLevel)}>
                            {report.results.confidenceLevel}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-1">
                            <Calendar className="h-4 w-4 text-muted-foreground" />
                            <span className="text-sm">{format(new Date(report.timestamp), "MMM dd, yyyy")}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button variant="outline" size="sm" onClick={() => setSelectedReport(report)}>
                                  <Eye className="h-4 w-4" />
                                </Button>
                              </DialogTrigger>
                              <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                                <DialogHeader>
                                  <DialogTitle>Detailed Analysis Report</DialogTitle>
                                  <DialogDescription>
                                    Complete analysis for {selectedReport?.name} ({selectedReport?.patientId})
                                  </DialogDescription>
                                </DialogHeader>
                                {selectedReport && (
                                  <div className="space-y-6">
                                    {/* Patient Info */}
                                    <div className="grid md:grid-cols-2 gap-4">
                                      <div>
                                        <h4 className="font-semibold mb-2">Patient Information</h4>
                                        <div className="space-y-1 text-sm">
                                          <p>
                                            <span className="font-medium">Age:</span> {selectedReport.age} years
                                          </p>
                                          <p>
                                            <span className="font-medium">Gender:</span> {selectedReport.gender}
                                          </p>
                                          <p>
                                            <span className="font-medium">Cancer Type:</span>{" "}
                                            {selectedReport.cancerType.toUpperCase()}
                                          </p>
                                          <p>
                                            <span className="font-medium">Gene:</span> {selectedReport.geneName} (
                                            {selectedReport.mutationStatus})
                                          </p>
                                        </div>
                                      </div>
                                      <div>
                                        <h4 className="font-semibold mb-2">Treatment Recommendation</h4>
                                        <div className="space-y-1 text-sm">
                                          <p>
                                            <span className="font-medium">Drug:</span>{" "}
                                            {selectedReport.results.recommendation.drugName}
                                          </p>
                                          <p>
                                            <span className="font-medium">Success Rate:</span>{" "}
                                            {selectedReport.results.successProbability}%
                                          </p>
                                          <p>
                                            <span className="font-medium">Confidence:</span>{" "}
                                            {selectedReport.results.confidenceLevel}
                                          </p>
                                        </div>
                                      </div>
                                    </div>

                                    {/* Analysis Details */}
                                    <div className="space-y-4">
                                      <div>
                                        <h4 className="font-semibold mb-2">Patient Feedback Analysis</h4>
                                        <p className="text-sm leading-relaxed">
                                          {selectedReport.results.patientFeedback}
                                        </p>
                                      </div>
                                      <div>
                                        <h4 className="font-semibold mb-2">Post-Treatment Plan</h4>
                                        <p className="text-sm leading-relaxed">
                                          {selectedReport.results.postTreatmentPlan}
                                        </p>
                                      </div>
                                      <div>
                                        <h4 className="font-semibold mb-2">Doctor Guidance</h4>
                                        <p className="text-sm leading-relaxed">
                                          {selectedReport.results.doctorGuidance}
                                        </p>
                                      </div>
                                    </div>
                                  </div>
                                )}
                              </DialogContent>
                            </Dialog>
                            <Button variant="outline" size="sm" onClick={() => handleDownloadReport(report)}>
                              <Download className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </div>
      </DashboardLayout>
    </AuthGuard>
  )
}
