"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { AuthGuard } from "@/components/auth-guard"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { type PatientAnalysis, type AnalysisResults, generateAnalysisResults } from "@/lib/analysis-engine"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts"
import { CheckCircle, AlertTriangle, FileText, Download, ArrowLeft } from "lucide-react"

export default function AnalysisPage() {
  const [patientData, setPatientData] = useState<PatientAnalysis | null>(null)
  const [results, setResults] = useState<AnalysisResults | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    const analysisData = localStorage.getItem("currentPatientAnalysis")
    if (analysisData) {
      const data = JSON.parse(analysisData) as PatientAnalysis
      setPatientData(data)
      const analysisResults = generateAnalysisResults(data)
      setResults(analysisResults)

      // Save to reports history
      const existingReports = JSON.parse(localStorage.getItem("patientReports") || "[]")
      const newReport = {
        ...data,
        results: analysisResults,
        reportId: `RPT-${Date.now()}`,
      }
      existingReports.push(newReport)
      localStorage.setItem("patientReports", JSON.stringify(existingReports))
    } else {
      router.push("/dashboard/patient")
    }
    setIsLoading(false)
  }, [router])

  const handleSaveReport = () => {
    if (patientData && results) {
      // In a real app, this would generate and download a PDF
      alert("Report saved successfully! In a real application, this would generate a downloadable PDF report.")
    }
  }

  const handleNewAnalysis = () => {
    localStorage.removeItem("currentPatientAnalysis")
    router.push("/dashboard/patient")
  }

  if (isLoading) {
    return (
      <AuthGuard>
        <DashboardLayout>
          <div className="flex items-center justify-center h-64">
            <div className="text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
              <p className="text-muted-foreground">Loading analysis results...</p>
            </div>
          </div>
        </DashboardLayout>
      </AuthGuard>
    )
  }

  if (!patientData || !results) {
    return (
      <AuthGuard>
        <DashboardLayout>
          <div className="p-6">
            <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>No analysis data found. Please start a new patient analysis.</AlertDescription>
            </Alert>
            <Button onClick={() => router.push("/dashboard/patient")} className="mt-4">
              Start New Analysis
            </Button>
          </div>
        </DashboardLayout>
      </AuthGuard>
    )
  }

  const pieData = [
    { name: "Success Probability", value: results.successProbability, color: "#3b82f6" },
    { name: "Risk Factor", value: 100 - results.successProbability, color: "#e5e7eb" },
  ]

  return (
    <AuthGuard>
      <DashboardLayout>
        <div className="p-6 space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground">Analysis Results</h1>
              <p className="text-muted-foreground mt-2">AI-powered treatment recommendations for {patientData.name}</p>
            </div>
            <div className="flex space-x-3">
              <Button variant="outline" onClick={() => router.push("/dashboard")}>
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Dashboard
              </Button>
              <Button onClick={handleSaveReport}>
                <Download className="mr-2 h-4 w-4" />
                Save Report
              </Button>
            </div>
          </div>

          {/* Patient Summary */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <FileText className="h-5 w-5" />
                <span>Patient Summary</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Patient ID</p>
                  <p className="font-medium">{patientData.patientId}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Age/Gender</p>
                  <p className="font-medium">
                    {patientData.age} years, {patientData.gender}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Cancer Type</p>
                  <p className="font-medium">{patientData.cancerType.toUpperCase()}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Genetic Profile</p>
                  <p className="font-medium">
                    {patientData.geneName} ({patientData.mutationStatus})
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Treatment Recommendation */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <CheckCircle className="h-5 w-5 text-green-600" />
                <span>Recommended Treatment</span>
                <Badge
                  variant={
                    results.confidenceLevel === "High"
                      ? "default"
                      : results.confidenceLevel === "Medium"
                        ? "secondary"
                        : "outline"
                  }
                >
                  {results.confidenceLevel} Confidence
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-semibold text-lg mb-2">{results.recommendation.drugName}</h4>
                  <p className="text-muted-foreground mb-3">{results.recommendation.mechanism}</p>
                  <div className="space-y-2">
                    <div>
                      <span className="text-sm font-medium">Dosage: </span>
                      <span className="text-sm">{results.recommendation.dosage}</span>
                    </div>
                    <div>
                      <span className="text-sm font-medium">Administration: </span>
                      <span className="text-sm">{results.recommendation.administration}</span>
                    </div>
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Clinical Reasoning</h4>
                  <p className="text-sm text-muted-foreground leading-relaxed">{results.recommendation.reasoning}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Success Prediction */}
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Success Probability</CardTitle>
                <CardDescription>Predicted treatment success rate</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center">
                    <div className="text-4xl font-bold text-primary mb-2">{results.successProbability}%</div>
                    <Progress value={results.successProbability} className="w-full" />
                  </div>
                  <div className="h-48">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={pieData}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={80}
                          paddingAngle={5}
                          dataKey="value"
                        >
                          {pieData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(value) => `${value}%`} />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Drug Effectiveness Comparison</CardTitle>
                <CardDescription>Predicted effectiveness scores</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={results.drugEffectiveness} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="drug" angle={-45} textAnchor="end" height={80} fontSize={12} />
                      <YAxis />
                      <Tooltip formatter={(value) => [`${value}%`, "Effectiveness"]} />
                      <Bar dataKey="score" fill="#3b82f6" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Risk Factors */}
          {results.riskFactors.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <span>Risk Factors & Considerations</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {results.riskFactors.map((risk, index) => (
                    <li key={index} className="flex items-start space-x-2">
                      <div className="w-2 h-2 bg-yellow-500 rounded-full mt-2 flex-shrink-0" />
                      <span className="text-sm">{risk}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          )}

          {/* Detailed Analysis */}
          <div className="grid md:grid-cols-1 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Patient Feedback Analysis</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm leading-relaxed">{results.patientFeedback}</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Post-Treatment Plan</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm leading-relaxed">{results.postTreatmentPlan}</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Doctor Guidance</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm leading-relaxed">{results.doctorGuidance}</p>
              </CardContent>
            </Card>
          </div>

          {/* Actions */}
          <div className="flex justify-center space-x-4 pt-6">
            <Button onClick={handleNewAnalysis} variant="outline">
              Analyze Another Patient
            </Button>
            <Button onClick={() => router.push("/dashboard/reports")}>View All Reports</Button>
          </div>
        </div>
      </DashboardLayout>
    </AuthGuard>
  )
}
