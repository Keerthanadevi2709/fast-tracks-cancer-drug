import { Navigation } from "@/components/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <div className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold mb-8 text-balance">About CancerDrug AI</h1>

          <div className="prose prose-lg max-w-none mb-12">
            <p className="text-lg text-muted-foreground leading-relaxed">
              CancerDrug AI is a cutting-edge decision support system designed to assist oncologists in making
              evidence-based treatment decisions. Our platform combines advanced machine learning algorithms with
              comprehensive genomic analysis to provide personalized treatment recommendations for cancer patients.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-12">
            <Card>
              <CardHeader>
                <CardTitle>Our Mission</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-base leading-relaxed">
                  To accelerate the discovery and application of effective cancer treatments through data science,
                  helping oncologists make more informed decisions and ultimately improving patient outcomes.
                </CardDescription>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>How It Works</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-base leading-relaxed">
                  Our AI analyzes patient genomic data, mutation status, gene expression levels, and treatment history
                  to predict drug efficacy and provide personalized treatment recommendations with confidence scores.
                </CardDescription>
              </CardContent>
            </Card>
          </div>

          <div className="text-center">
            <h2 className="text-2xl font-semibold mb-4">Ready to Get Started?</h2>
            <p className="text-muted-foreground mb-6">Experience the power of AI-driven cancer treatment analysis.</p>
            <Button asChild size="lg">
              <Link href="/login">Doctor Login</Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
